const carForm = document.querySelectorAll('input')
const sendButton = document.querySelector('#submitBtn')

let today = new Date()
today = today.getFullYear()

let originalObject = {
  brand:'',
  model:'',
  year:'',
  color:'',
  plate:'',
  fuel:'',
  owner:''
  // Construa seu objeto aqui
}

let clonedObj = Object.assign({}, originalObject);

//Ação realizada ao clicar em enviar
sendButton.onclick = function(e) {
  // Função que processo o objeto
  processForm(carForm,clonedObj)
  cleanForm(carForm)
}


function processForm(carForm,clonedObj){

  carForm.forEach(element => {
  })
  

}

function cleanForm(form){
  form.forEach(element => {
    element.value = ''
  })
}
