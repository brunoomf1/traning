document.addEventListener('DOMContentLoaded', function () {
	const imageList = document.getElementById('imageList');
	const modalImg = document.getElementById('modalImg');
	const modal = document.getElementById('myModal');
	const closeModalBtn = document.getElementById('closeModalBtn');
	
	// Adicione aqui seu código
  });
  